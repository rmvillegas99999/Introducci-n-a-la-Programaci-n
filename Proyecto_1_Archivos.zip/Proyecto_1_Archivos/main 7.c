#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	float V,R,I;
	
	printf("Este programa sirve para calcular resistencias(R) en base a su: ");
	
	
	printf("\n\nVoltaje (V): ");
    scanf("%f",&V);
	
	printf("\nCorriente(I): ");
    scanf("%f",&I);
    
	R= V/I;
	
	printf("R = %f\n\n",R);
	
	system("PAUSE");
	return 0;
	
}
