#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	float F,C,temp;
	char unidades;
	
	printf("Introduzca la temperatura que quiere convertir (F para Farenheit, C para Celsius)\n");
	scanf("%c",&unidades);
	
    printf("\nCantidad de grados que quiere convertir: \n ");
    scanf("%f",&temp);
    
    (unidades== 'C' )? ((F= (1.8*temp)+32)): (C= (temp-32)/1.8);
    
    (unidades== 'C')? printf("F = %f\n",F): printf("C = %f\n",C);
    
    system ("PAUSE");
	return 0;
}
