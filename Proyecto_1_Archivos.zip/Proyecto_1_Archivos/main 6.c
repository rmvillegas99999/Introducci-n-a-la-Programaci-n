#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  
    int p, densA, densD, d;
    float vol, pi, g, h;
    char liquid;
    
    pi= 3.1416; 
    g= 9.81;
    densA= 1000;
    densD= 820;
   
   
    printf("�Que tipo de liquido hay en el contenedor?\nTeclee 'a' si es agua o 'd' si es Diesel\n\nLiquido: ");
    scanf("%c",&liquid);
    
    printf("\nDiametro del contenedor: ");
    scanf("%i",&d);
    
    printf("\nPresion Hidrostatica: ");
    scanf("%i",&p);
    
    
    (liquid == 'a')? (h=p/(densA*g)): (h=p/(densD*g));
    
    vol= pi*(d/2)*(d/2)*h;
    
    printf("\nEl contenedor tiene %f metros cubicos de liquido\n\n",vol);
  
  system("PAUSE");	
  return 0;
}
